// src/app.ts
var app_default = {
  async lambda(request) {
    console.log(request.headers.get("x-amzn-function-arn"));
    const obj = { foo: "bar" };
    console.log(Bun.inspect(obj));
    return new Response("Hello from Lambda!", {
      status: 200,
      headers: {
        "Content-Type": "text/plain"
      }
    });
  }
};
export {
  app_default as default
};
